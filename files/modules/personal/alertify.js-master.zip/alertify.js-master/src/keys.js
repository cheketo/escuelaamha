define([], function () {
    "use strict";

    var keys = {
        ENTER : 13,
        ESC   : 27,
        SPACE : 32
    };

    return keys;
});
